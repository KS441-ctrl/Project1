import React from 'react'

function background() {
  return (
    <div >background</div>
  )
}

export default background