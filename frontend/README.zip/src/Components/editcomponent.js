import React, { useState } from 'react';
import '../Components/css/editcomponent.css';
import Slider from '../Components/slider';

const Editcomponent = () => {
  const [selectedRig, setSelectedRig] = useState(null);
  const [showForm, setShowForm] = useState(true);
  const [formData, setFormData] = useState({
    s_no:"",
    rig_name: "",
    short_name: "",
    customer_name: "",
    details: "",
    design: "",
    location: "",
    hull_no: "",
    design_2: "",
    new_group: ""
  });
  const handleInputChange = (event) => {
    setFormData({
      ...formData,
      [event.target.name]: event.target.value,
      s_no: formData.length + 1
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    fetch('http://localhost:8002/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
      console.log(data);
      setFormData({
        s_no:"",
        rig_name: "",
        short_name: "",
        customer_name: "",
        details: "",
        design: "",
        location: "",
        hull_no: "",
        design_2: "",
        new_group: ""
      });
    })
    .catch(error => console.log(error));
  };

  const handleEditSubmit = (event) => {
    event.preventDefault();
    fetch('http://localhost:8002/edit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(selectedRig)
    })
    .then(response => response.json())
    .then(data => {
      setShowForm(false);
      console.log(data);
      setSelectedRig(null);
    })
    .catch(error => console.log(error));
  };

  const handleEditInputChange = (event) => {
    setSelectedRig({
      ...selectedRig,
      [event.target.name]: event.target.value, // Replace dot with comma
    });
  };
  
  return (
    <div>
      {selectedRig && (
        <div className="rig-details">
          <h2>{selectedRig.rig_name}</h2>
          <p>{selectedRig.details}</p>
          <Slider />
          <button onClick={() => setShowForm(true)}>Edit</button>
        </div>
      )}
      {showForm && (
        <div className="form-container">
          <form onSubmit={selectedRig ? handleEditSubmit : handleSubmit}>
            <label>
              Rig name:
              <input type="text" name="rig_name" value={selectedRig ? selectedRig.rig_name : formData.rig_name} onChange={selectedRig ? handleEditInputChange : handleInputChange} />
            </label>
            <label>
              Short name:
              <input type="text" name="short_name" value={selectedRig ? selectedRig.short_name : formData.short_name} onChange={selectedRig ? handleEditInputChange : handleInputChange} />
            </label>
            <label>
              Customer name:
              <input type="text" name="customer_name" value={selectedRig ? selectedRig.customer_name : formData.customer_name} onChange={selectedRig ? handleEditInputChange : handleInputChange} />
            </label>
            <label>
              Details:
              <input type="text" name="details" value={selectedRig ? selectedRig.details : formData.details} onChange={selectedRig ? handleEditInputChange : handleInputChange} />
            </label>
            <label>
              Design:
              <input type="text" name="design" value={selectedRig ? selectedRig.design : formData.design} onChange={selectedRig ? handleEditInputChange : handleInputChange} />
            </label>
            <label>
              Location:
              <input type="text" name="location" value={selectedRig ? selectedRig.location : formData.location} onChange={selectedRig ? handleEditInputChange : handleInputChange} />
            </label>
            <label>
              Hull number:
              <input type="text" name="hull_no" value={selectedRig ? selectedRig.hull_no : formData.hull_no} onChange={selectedRig ? handleEditInputChange : handleInputChange} />
            </label>
            <label>
              Design 2:
              <input type="text" name="design_2" value={selectedRig ? selectedRig.design_2 : formData.design_2} onChange={selectedRig ? handleEditInputChange : handleInputChange} />
            </label>
            <button type="submit">{selectedRig ? 'Save' : 'Create'}</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Editcomponent;
