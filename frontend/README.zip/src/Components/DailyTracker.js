import React from 'react'

export default function DailyTracker() {
  return (
    <div>DailyTracker</div>
  )
}
