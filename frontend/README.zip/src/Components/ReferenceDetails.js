import React from 'react'

export default function ReferenceDetails() {
  return (
    <div>ReferenceDetails</div>
  )
}
