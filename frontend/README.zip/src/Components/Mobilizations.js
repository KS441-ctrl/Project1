import React from 'react'

function Mobilizations() {
  return (
    <div>Mobilizations</div>
  )
}

export default Mobilizations