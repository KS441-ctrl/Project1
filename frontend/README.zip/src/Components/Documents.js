import React from 'react'

function Documents() {
  return (
    <div>Documents</div>
  )
}

export default Documents
